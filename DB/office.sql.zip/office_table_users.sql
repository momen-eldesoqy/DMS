
-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `feature` varchar(50) NOT NULL,
  `date` date NOT NULL,
  `decision` varchar(50) NOT NULL,
  `orders` varchar(150) NOT NULL,
  `enemy` varchar(50) NOT NULL,
  `address` varchar(100) NOT NULL,
  `subject` int(11) NOT NULL,
  `rolnum` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `feature`, `date`, `decision`, `orders`, `enemy`, `address`, `subject`, `rolnum`) VALUES(2, 'مؤمن', '', '0000-00-00', '', '', '', '', 0, 0);
